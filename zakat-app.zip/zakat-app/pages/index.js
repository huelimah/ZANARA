import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { supabase } from "../lib/supabaseClient";

const rupiah = (n) =>
  new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    isFinite(n) ? n : 0
  );

export default function Home() {
  const calcRef = useRef(null);
  const bayarRef = useRef(null);
  const transparansiRef = useRef(null);
  const scrollTo = (ref) => ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });

  const [lembaga, setLembaga] = useState(null);
  const [transaksi, setTransaksi] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data: lembagaData } = await supabase.from("lembaga").select("*").limit(1).single();
      const { data: transaksiData } = await supabase
        .from("transaksi")
        .select("*")
        .order("tanggal", { ascending: false })
        .limit(20);
      setLembaga(lembagaData);
      setTransaksi(transaksiData || []);
      setLoading(false);
    };
    load();
  }, []);

  const totalTersalurkan = transaksi.filter((t) => t.tipe === "keluar").reduce((a, b) => a + Number(b.jumlah), 0);

  // Kalkulator
  const [tab, setTab] = useState("fitrah");
  const [jiwa, setJiwa] = useState(1);
  const [hargaFitrah, setHargaFitrah] = useState(45000);
  const [hartaMaal, setHartaMaal] = useState(0);
  const [hutangMaal, setHutangMaal] = useState(0);
  const [hargaEmas, setHargaEmas] = useState(1400000);
  const [penghasilan, setPenghasilan] = useState(0);

  const nisab = 85 * hargaEmas;
  const nisabBulanan = nisab / 12;
  const zakatFitrah = jiwa * hargaFitrah;
  const dasarMaal = Math.max(hartaMaal - hutangMaal, 0);
  const zakatMaal = dasarMaal >= nisab ? dasarMaal * 0.025 : 0;
  const zakatPenghasilan = penghasilan >= nisabBulanan ? penghasilan * 0.025 : 0;
  const hasilAktif = tab === "fitrah" ? zakatFitrah : tab === "maal" ? zakatMaal : zakatPenghasilan;
  const labelAktif = tab === "fitrah" ? "Zakat Fitrah" : tab === "maal" ? "Zakat Maal" : "Zakat Penghasilan";

  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    if (!lembaga) return;
    navigator.clipboard?.writeText(lembaga.rekening.replace(/\s/g, ""));
    setCopied(true);
    setTimeout(() => setCopied(false), 1800);
  };

  const waLink = () => {
    if (!lembaga) return "#";
    const pesan = `Assalamu'alaikum, saya sudah transfer ${labelAktif} sebesar ${rupiah(
      hasilAktif
    )} ke rekening ${lembaga.bank}. Berikut konfirmasinya, insyaAllah bukti transfer menyusul.`;
    return `https://wa.me/${lembaga.wa_number}?text=${encodeURIComponent(pesan)}`;
  };

  if (loading) {
    return <div className="container"><p className="muted">Memuat...</p></div>;
  }

  return (
    <div className="container">
      <p className="muted" style={{ fontSize: 14 }}>Assalamu'alaikum,</p>
      <h1 className="title-serif" style={{ fontSize: 26, marginTop: 2 }}>{lembaga?.nama}</h1>

      {/* Hero */}
      <div className="card" style={{ marginTop: 24 }}>
        <p className="eyebrow">Total Zakat Tersalurkan</p>
        <p className="hero-number">{rupiah(totalTersalurkan)}</p>
        <p className="muted" style={{ fontSize: 13, marginTop: 8 }}>
          {lembaga?.bank} · {lembaga?.rekening}
        </p>
        <button className="btn btn-gold" style={{ marginTop: 16 }} onClick={() => scrollTo(calcRef)}>
          Tunaikan Zakat
        </button>
      </div>

      {/* Aksi cepat */}
      <div style={{ marginTop: 32 }}>
        <p className="eyebrow">Aksi Cepat</p>
        <div className="grid-2">
          <button className="tile" onClick={() => scrollTo(calcRef)}>Kalkulator Zakat</button>
          <button className="tile" onClick={() => scrollTo(bayarRef)}>Bayar Zakat</button>
          <button className="tile" onClick={() => scrollTo(transparansiRef)}>Transparansi Publik</button>
          <Link href="/login" className="tile">Login Bendahara</Link>
        </div>
      </div>

      {/* Kalkulator */}
      <div ref={calcRef} style={{ marginTop: 40 }}>
        <p className="section-title">Kalkulator Zakat</p>
        <p className="muted" style={{ fontSize: 13, marginTop: 4 }}>Hitung kewajiban zakatmu secara otomatis.</p>

        <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
          {[["fitrah", "Fitrah"], ["maal", "Maal"], ["penghasilan", "Penghasilan"]].map(([key, label]) => (
            <button
              key={key}
              className={`tab ${tab === key ? "tab-active" : ""}`}
              onClick={() => setTab(key)}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="card" style={{ marginTop: 16, display: "flex", flexDirection: "column", gap: 16 }}>
          {tab === "fitrah" && (
            <>
              <div>
                <label className="field-label">Jumlah jiwa</label>
                <input className="input" type="number" min={0} value={jiwa} onChange={(e) => setJiwa(Number(e.target.value))} />
              </div>
              <div>
                <label className="field-label">Harga per jiwa (setara 2,5 kg beras)</label>
                <input className="input" type="number" min={0} value={hargaFitrah} onChange={(e) => setHargaFitrah(Number(e.target.value))} />
              </div>
            </>
          )}

          {tab === "maal" && (
            <>
              <div>
                <label className="field-label">Total harta (tabungan, emas, aset niaga)</label>
                <input className="input" type="number" min={0} value={hartaMaal} onChange={(e) => setHartaMaal(Number(e.target.value))} />
              </div>
              <div>
                <label className="field-label">Hutang jatuh tempo (opsional)</label>
                <input className="input" type="number" min={0} value={hutangMaal} onChange={(e) => setHutangMaal(Number(e.target.value))} />
              </div>
              <div>
                <label className="field-label">Harga emas per gram (perkiraan, sesuaikan sendiri)</label>
                <input className="input" type="number" min={0} value={hargaEmas} onChange={(e) => setHargaEmas(Number(e.target.value))} />
              </div>
              <p className="muted" style={{ fontSize: 12 }}>
                Nisab (85gr emas): {rupiah(nisab)} — wajib zakat jika harta di atas nisab dan sudah dimiliki 1 tahun (haul).
              </p>
            </>
          )}

          {tab === "penghasilan" && (
            <>
              <div>
                <label className="field-label">Penghasilan bulanan</label>
                <input className="input" type="number" min={0} value={penghasilan} onChange={(e) => setPenghasilan(Number(e.target.value))} />
              </div>
              <p className="muted" style={{ fontSize: 12 }}>
                Nisab bulanan: {rupiah(nisabBulanan)} — dihitung dari 85gr emas dibagi 12 bulan.
              </p>
            </>
          )}

          <div style={{ borderTop: "1px solid var(--border)", paddingTop: 12 }}>
            <p className="muted" style={{ fontSize: 13 }}>{labelAktif} yang harus dibayar</p>
            <p className="hero-number" style={{ fontSize: 28, color: "var(--gold-bright)" }}>{rupiah(hasilAktif)}</p>
          </div>

          <button className="btn btn-gold" onClick={() => scrollTo(bayarRef)}>Bayar Sekarang</button>
        </div>
      </div>

      {/* Bayar */}
      <div ref={bayarRef} style={{ marginTop: 40 }}>
        <p className="section-title">Pembayaran</p>
        <div className="card" style={{ marginTop: 16 }}>
          <p className="muted" style={{ fontSize: 13 }}>{lembaga?.bank}</p>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 4 }}>
            <p className="title-serif" style={{ fontSize: 22 }}>{lembaga?.rekening}</p>
            <button className="btn-outline" onClick={handleCopy}>{copied ? "Disalin" : "Salin"}</button>
          </div>
          <p className="muted" style={{ fontSize: 12, marginTop: 6 }}>a.n. {lembaga?.nama}</p>

          <a href={waLink()} target="_blank" rel="noreferrer" className="btn btn-wa" style={{ marginTop: 20 }}>
            Konfirmasi via WhatsApp
          </a>
          <p className="muted" style={{ fontSize: 12, marginTop: 8 }}>
            Setelah transfer, kirim bukti pembayaran lewat WhatsApp agar segera dicatat bendahara.
          </p>
        </div>
      </div>

      {/* Transparansi */}
      <div ref={transparansiRef} style={{ marginTop: 40 }}>
        <p className="section-title">Transparansi Publik</p>
        <p className="muted" style={{ fontSize: 13, marginTop: 4 }}>
          Riwayat zakat masuk dan tersalurkan (nama disamarkan untuk menjaga privasi).
        </p>

        <div style={{ marginTop: 16 }}>
          {transaksi.length === 0 && <p className="muted" style={{ fontSize: 13 }}>Belum ada transaksi tercatat.</p>}
          {transaksi.map((t) => (
            <div key={t.id} className="divider-row">
              <div>
                <p style={{ fontSize: 14, fontWeight: 500 }}>{t.kategori}</p>
                <p className="muted" style={{ fontSize: 12 }}>
                  {t.nama_pihak} · {new Date(t.tanggal).toLocaleDateString("id-ID")}
                </p>
              </div>
              <p style={{ fontWeight: 600, fontSize: 14, color: t.tipe === "masuk" ? "var(--gold-bright)" : "#7fa98f" }}>
                {t.tipe === "masuk" ? "+" : "-"}{rupiah(t.jumlah)}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
