import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import { supabase } from "../lib/supabaseClient";

const rupiah = (n) =>
  new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(
    isFinite(n) ? n : 0
  );

export default function Admin() {
  const router = useRouter();
  const [checking, setChecking] = useState(true);
  const [transaksi, setTransaksi] = useState([]);
  const [lembaga, setLembaga] = useState(null);

  // form transaksi baru
  const [tipe, setTipe] = useState("masuk");
  const [kategori, setKategori] = useState("Zakat Maal");
  const [namaPihak, setNamaPihak] = useState("Hamba Allah");
  const [jumlah, setJumlah] = useState("");
  const [tanggal, setTanggal] = useState(new Date().toISOString().slice(0, 10));
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    const check = async () => {
      const { data } = await supabase.auth.getUser();
      if (!data?.user) {
        router.push("/login");
        return;
      }
      setChecking(false);
      loadData();
    };
    check();
  }, []);

  const loadData = async () => {
    const { data: t } = await supabase.from("transaksi").select("*").order("tanggal", { ascending: false });
    const { data: l } = await supabase.from("lembaga").select("*").limit(1).single();
    setTransaksi(t || []);
    setLembaga(l);
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.push("/login");
  };

  const handleAddTransaksi = async (e) => {
    e.preventDefault();
    setMsg("");
    if (!jumlah || Number(jumlah) <= 0) {
      setMsg("Jumlah harus lebih dari 0.");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("transaksi").insert({
      tipe,
      kategori,
      nama_pihak: namaPihak || "Hamba Allah",
      jumlah: Number(jumlah),
      tanggal,
    });
    setSaving(false);
    if (error) {
      setMsg("Gagal menyimpan: " + error.message);
      return;
    }
    setJumlah("");
    setMsg("Transaksi tersimpan dan langsung tampil di halaman publik.");
    loadData();
  };

  const handleDelete = async (id) => {
    if (!confirm("Hapus transaksi ini?")) return;
    await supabase.from("transaksi").delete().eq("id", id);
    loadData();
  };

  const handleSaveLembaga = async (e) => {
    e.preventDefault();
    await supabase.from("lembaga").update({
      nama: lembaga.nama,
      bank: lembaga.bank,
      rekening: lembaga.rekening,
      wa_number: lembaga.wa_number,
    }).eq("id", lembaga.id);
    setMsg("Data lembaga tersimpan.");
  };

  if (checking) return <div className="container"><p className="muted">Memeriksa akses...</p></div>;

  return (
    <div className="container" style={{ maxWidth: 560 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <p className="section-title">Dashboard Bendahara</p>
        <button className="btn-outline" onClick={handleLogout}>Keluar</button>
      </div>

      {msg && <p style={{ color: "var(--gold-bright)", fontSize: 13, marginTop: 12 }}>{msg}</p>}

      {/* Tambah transaksi */}
      <p className="eyebrow" style={{ marginTop: 28 }}>Catat Transaksi Baru</p>
      <form onSubmit={handleAddTransaksi} className="card" style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 14 }}>
        <div style={{ display: "flex", gap: 8 }}>
          <button type="button" className={`tab ${tipe === "masuk" ? "tab-active" : ""}`} onClick={() => setTipe("masuk")}>Zakat Masuk</button>
          <button type="button" className={`tab ${tipe === "keluar" ? "tab-active" : ""}`} onClick={() => setTipe("keluar")}>Zakat Tersalurkan</button>
        </div>

        <div>
          <label className="field-label">Kategori</label>
          <input className="input" value={kategori} onChange={(e) => setKategori(e.target.value)}
            placeholder={tipe === "masuk" ? "Zakat Maal / Fitrah / Penghasilan" : "Bantuan Fakir / Ibnu Sabil / dll"} />
        </div>

        <div>
          <label className="field-label">Nama pihak (akan disamarkan di publik jika perlu)</label>
          <input className="input" value={namaPihak} onChange={(e) => setNamaPihak(e.target.value)} />
        </div>

        <div style={{ display: "flex", gap: 12 }}>
          <div style={{ flex: 1 }}>
            <label className="field-label">Jumlah (Rp)</label>
            <input className="input" type="number" min={0} value={jumlah} onChange={(e) => setJumlah(e.target.value)} />
          </div>
          <div style={{ flex: 1 }}>
            <label className="field-label">Tanggal</label>
            <input className="input" type="date" value={tanggal} onChange={(e) => setTanggal(e.target.value)} />
          </div>
        </div>

        <button className="btn btn-gold" type="submit" disabled={saving}>
          {saving ? "Menyimpan..." : "Simpan & Tampilkan ke Publik"}
        </button>
      </form>

      {/* Data lembaga */}
      {lembaga && (
        <>
          <p className="eyebrow" style={{ marginTop: 28 }}>Data Lembaga (rekening & WA)</p>
          <form onSubmit={handleSaveLembaga} className="card" style={{ marginTop: 8, display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <label className="field-label">Nama lembaga</label>
              <input className="input" value={lembaga.nama} onChange={(e) => setLembaga({ ...lembaga, nama: e.target.value })} />
            </div>
            <div>
              <label className="field-label">Nama bank</label>
              <input className="input" value={lembaga.bank} onChange={(e) => setLembaga({ ...lembaga, bank: e.target.value })} />
            </div>
            <div>
              <label className="field-label">Nomor rekening</label>
              <input className="input" value={lembaga.rekening} onChange={(e) => setLembaga({ ...lembaga, rekening: e.target.value })} />
            </div>
            <div>
              <label className="field-label">Nomor WhatsApp (format 62xxxxxxxxxx)</label>
              <input className="input" value={lembaga.wa_number} onChange={(e) => setLembaga({ ...lembaga, wa_number: e.target.value })} />
            </div>
            <button className="btn btn-gold" type="submit">Simpan Data Lembaga</button>
          </form>
        </>
      )}

      {/* Daftar transaksi */}
      <p className="eyebrow" style={{ marginTop: 28 }}>Semua Transaksi</p>
      <div className="card" style={{ marginTop: 8 }}>
        {transaksi.length === 0 && <p className="muted" style={{ fontSize: 13 }}>Belum ada transaksi.</p>}
        {transaksi.map((t) => (
          <div key={t.id} className="divider-row">
            <div>
              <p style={{ fontSize: 14, fontWeight: 500 }}>{t.kategori}</p>
              <p className="muted" style={{ fontSize: 12 }}>
                {t.nama_pihak} · {new Date(t.tanggal).toLocaleDateString("id-ID")}
              </p>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <p style={{ fontWeight: 600, fontSize: 14, color: t.tipe === "masuk" ? "var(--gold-bright)" : "#7fa98f" }}>
                {t.tipe === "masuk" ? "+" : "-"}{rupiah(t.jumlah)}
              </p>
              <button className="btn-outline" onClick={() => handleDelete(t.id)}>Hapus</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
