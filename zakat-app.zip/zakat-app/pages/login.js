import { useState } from "react";
import { useRouter } from "next/router";
import { supabase } from "../lib/supabaseClient";

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setLoading(false);
    if (error) {
      setError("Email atau kata sandi salah.");
      return;
    }
    router.push("/admin");
  };

  return (
    <div className="container" style={{ paddingTop: 80 }}>
      <p className="section-title">Login Bendahara</p>
      <p className="muted" style={{ fontSize: 13, marginTop: 4 }}>
        Halaman ini khusus untuk pengurus lembaga yang mengelola data zakat.
      </p>

      <form onSubmit={handleLogin} className="card" style={{ marginTop: 20, display: "flex", flexDirection: "column", gap: 16 }}>
        <div>
          <label className="field-label">Email</label>
          <input className="input" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
        </div>
        <div>
          <label className="field-label">Kata sandi</label>
          <input className="input" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
        </div>
        {error && <p className="error-text">{error}</p>}
        <button className="btn btn-gold" type="submit" disabled={loading}>
          {loading ? "Memproses..." : "Masuk"}
        </button>
      </form>

      <p className="muted" style={{ fontSize: 12, marginTop: 16 }}>
        Belum punya akun? Akun bendahara dibuat lewat Supabase Dashboard, bukan lewat halaman ini
        (lihat panduan langkah pembuatan akun pertama).
      </p>
    </div>
  );
}
