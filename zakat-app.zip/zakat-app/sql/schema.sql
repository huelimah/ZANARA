-- ============================================
-- SKEMA DATABASE ZAKAT APP
-- Cara pakai: buka Supabase > SQL Editor > New query
-- tempel semua isi file ini > klik Run
-- ============================================

-- Tabel profil lembaga (rekening, nomor WA, dsb)
create table if not exists lembaga (
  id uuid primary key default gen_random_uuid(),
  nama text not null default 'Lembaga Amil Zakat',
  bank text not null default '',
  rekening text not null default '',
  wa_number text not null default '',
  updated_at timestamp with time zone default now()
);

-- Baris awal (isi nanti lewat halaman admin)
insert into lembaga (nama, bank, rekening, wa_number)
select 'Lembaga Amil Zakat', 'Nama Bank', '0000000000', '62800000000'
where not exists (select 1 from lembaga);

-- Tabel transaksi (zakat masuk dari muzakki, zakat keluar ke mustahik)
create table if not exists transaksi (
  id uuid primary key default gen_random_uuid(),
  tipe text not null check (tipe in ('masuk', 'keluar')),
  kategori text not null,               -- contoh: 'Zakat Maal', 'Bantuan Fakir'
  nama_pihak text not null default 'Hamba Allah',  -- nama disamarkan untuk publik
  jumlah numeric not null check (jumlah >= 0),
  tanggal date not null default current_date,
  created_at timestamp with time zone default now()
);

-- Aktifkan Row Level Security (wajib supaya data aman)
alter table lembaga enable row level security;
alter table transaksi enable row level security;

-- Semua orang (termasuk publik tanpa login) boleh MELIHAT data
create policy "publik boleh lihat lembaga" on lembaga
  for select using (true);

create policy "publik boleh lihat transaksi" on transaksi
  for select using (true);

-- Hanya bendahara yang sudah login yang boleh UBAH data
create policy "bendahara boleh ubah lembaga" on lembaga
  for update to authenticated using (true);

create policy "bendahara boleh tambah transaksi" on transaksi
  for insert to authenticated with check (true);

create policy "bendahara boleh hapus transaksi" on transaksi
  for delete to authenticated using (true);

create policy "bendahara boleh ubah transaksi" on transaksi
  for update to authenticated using (true);
